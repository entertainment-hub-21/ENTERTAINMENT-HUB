if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js');
  });
}
setTimeout(() => {
  alert('Install Entertainment Hub for quick access!');
}, 10000);